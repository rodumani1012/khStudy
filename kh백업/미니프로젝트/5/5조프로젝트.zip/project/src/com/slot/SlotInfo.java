package com.slot;

public class SlotInfo {
	private int myno;
	private String myname;

	public SlotInfo() {
		super();
	}

	// �α��� �� ��Ϲ�ȣ getter
	public int getMyno() {
		return myno;
	}

	// ��ȣ setter
	public void setMyno(int myno) {
		this.myno = myno;
	}

	// �α��� �� �̸�getter
	public String getMyname() {
		return myname;
	}

	// �̸�setter
	public void setMyname(String myname) {
		this.myname = myname;
	}

}