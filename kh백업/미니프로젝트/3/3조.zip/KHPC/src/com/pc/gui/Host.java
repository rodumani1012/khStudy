package com.pc.gui;

import javax.swing.JFrame;

public class Host extends JFrame{

	
}
