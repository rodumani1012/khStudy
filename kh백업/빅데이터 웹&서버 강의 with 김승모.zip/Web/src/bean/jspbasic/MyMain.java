package bean.jspbasic;

public class MyMain {	
	
	String name = "홍길동";
	public String getName() {
		return name;
	}
	public static void main(String[] args) {
		

	}

}
