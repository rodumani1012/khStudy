package class10_class.ep01_calssdesign.message;

public class Message {

	public void sayHello() {
		System.out.println("Hello");
	}

	public void sayWorld() {
		System.out.println("World");
	}

	public void sayMesssage(String message) {
		System.out.println("message=[" + message + "]");
	}

}
