package c0716.roop_example;

public class MainWhile {

	public static void main(String[] args) {
		int i = 1;
		while (i < 10) {
			System.out.println("i = [" + i + "]");
			i += 1;
		}

	}

}
