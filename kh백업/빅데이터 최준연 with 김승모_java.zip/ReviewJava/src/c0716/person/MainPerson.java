package c0716.person;

public class MainPerson {

	public static void main(String[] args) {
		Person p = new Person();
		p.setName("Kim");
		p.setAge(20);
		p.printInfo();
		

	}

}
