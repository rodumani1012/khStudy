package c0713.message;

public class MainMessage {

	public static void main(String[] args) {
		
		Message m1 = new Message();
		m1.sayHello();
		m1.sayWorld();
		m1.sayMessage("Welcome");
	}

}
