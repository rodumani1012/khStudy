package c0713.data;

public class Maindata {

	public static void main(String[] args) {
		Data d = new Data();
		System.out.println("����=[" + d.getAge()+ "]");
	}

}
