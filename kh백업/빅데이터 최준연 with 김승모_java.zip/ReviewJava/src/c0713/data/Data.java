package c0713.data;

public class Data {
	int age = 30;
	String str = "Hello";
	public int getAge() {
		return age;
	}
}
