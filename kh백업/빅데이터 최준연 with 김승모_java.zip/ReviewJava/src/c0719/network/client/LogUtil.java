package c0719.network.client;

public class LogUtil {

	public static void printInfo(String message) {
		System.out.println(message);
		
	}
	public static void printMsg(String message) {
		System.out.println("[" + CalendarUtil.getDateTime() + "] " + message);
	}
	public static void printMsgGuide(String message) {
		System.out.println("[" + CalendarUtil.getDateTime() + "] " + message);
	}

}
