package c0719.thread;

public class Work {
	
	public void run() {
		for (int i = 0; i < 1000; i++) {
			System.out.print("-");
		}
	}
}
