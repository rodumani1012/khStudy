package com.jari;

public class jari {

	private static boolean isSame(int[] arr, int insert) {

		for (int i = insert - 1; i >= 0; i--) {
			if (arr[insert] == arr[i]) {
				return true;

			}
		}
		return false;
	}

	// 15(이승근) 23(정햇나라) 27(한진희) 9(신은정) 21(정서희) 26(한지수)

	public static void main(String[] args) {

		int[][] a = new int[5][6];

		// 눈 나쁜 사람 3줄 안에 들어가
		int[] eye = { 15, 23, 27, 9, 21, 26 };

		int p = 0;

		int i = (int) (Math.random() * (2 - 0 + 1) + 0);
		int j = (int) (Math.random() * (5 - 0 + 1) + 0);

		for (int t = 0; t < 6;) {
			if (String.valueOf(a[i][j]).equals("0")) {
				a[i][j] = eye[p];
				p++;
				t++;
			} else {
				i = (int) (Math.random() * (2 - 0 + 1) + 0);
				j = (int) (Math.random() * (5 - 0 + 1) + 0);
			}
		}

		// 남는 자리에 나머지 들어가

		int[] people = new int[24];

		for (int s = 0; s < people.length;) {

			do {
				people[s] = (int) (Math.random() * (30 - 1 + 1) + 1);
			} while (people[s] == 15 || people[s] == 23 || people[s] == 27 || people[s] == 9 || people[s] == 21
					|| people[s] == 26);
			if (!isSame(people, s)) {
				s++;
			}
		}

		for (int z = 0; z < 24;) {
			if (String.valueOf(a[i][j]).equals("0")) {
				a[i][j] = people[z];
				p++;
				z++;
			} else {
				i = (int) (Math.random() * (4 - 0 + 1) + 0);
				j = (int) (Math.random() * (5 - 0 + 1) + 0);
			}
		}

		for (int q = 0; q < a.length; q++) {
			for (int w = 0; w < a[q].length; w++) {
				System.out.print("\t" + a[q][w]);
				if ((w + 1) % 6 == 0) {
					System.out.println();
				}
			}
		}
	}
}