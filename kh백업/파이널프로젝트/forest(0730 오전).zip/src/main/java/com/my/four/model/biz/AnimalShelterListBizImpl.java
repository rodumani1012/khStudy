package com.my.four.model.biz;

public class AnimalShelterListBizImpl implements AnimalShelterListBiz {

}
