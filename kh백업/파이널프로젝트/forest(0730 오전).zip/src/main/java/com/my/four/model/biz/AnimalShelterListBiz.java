package com.my.four.model.biz;

public interface AnimalShelterListBiz {

}
