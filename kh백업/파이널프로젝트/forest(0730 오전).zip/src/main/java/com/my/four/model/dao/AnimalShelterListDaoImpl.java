package com.my.four.model.dao;

import java.util.List;

import com.my.four.model.dto.AnimalShelterListDto;

public class AnimalShelterListDaoImpl implements AnimalShelterListDao {

	@Override
	public int insert(List<AnimalShelterListDto> dtos) {
		// TODO Auto-generated method stub
		return 0;
	}

}
