package com.my.four.model.biz;

import java.util.List;

import com.my.four.model.dto.AnimalShelterListDto;

public interface AnimalShelterListBiz {

	public int insert(List<AnimalShelterListDto> dtos);
}
