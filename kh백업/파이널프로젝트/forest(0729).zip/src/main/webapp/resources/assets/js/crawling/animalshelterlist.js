
$(function(){
	getJson();
});

function getJson() {
	
	$.getJSON("")
}