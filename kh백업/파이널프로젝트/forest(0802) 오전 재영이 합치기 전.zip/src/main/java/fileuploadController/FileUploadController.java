package fileuploadController;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartRequest;

import com.my.four.model.biz.ContestBoardBiz;

@Controller
public class FileUploadController{

	private static final Logger logger = LoggerFactory.getLogger(FileUploadController.class);

	public String ContesetWriteForm(HttpServletRequest request, Model model) {
		// 경로체크
		
		
		return "contestboard";
	}


}
