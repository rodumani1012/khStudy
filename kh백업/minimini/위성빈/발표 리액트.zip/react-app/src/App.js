import React, { Component } from 'react';
import './App.css';

class App extends Component {
  constructor(props) {
    super(props)
    this.state = {
      list: ['Home', 'React'],
      select: "Home",
      article: [{ name: 'Home', description: "Welcome, Home" }, { name: 'React', description: "WOW, React" }]
    }
  }
  render() {
    var _article = "";
    this.state.article.map(function (item) {
      if (this.state.select === item.name) {
        _article = <Article content={item.description}></Article>
      }
    }.bind(this))
    return (
      <div className="App">
        <Title title="Hello, React!"></Title>
        <Nav data={this.state.list} clickNav={function (_item) {
          this.setState({
            select: _item
          })
        }.bind(this)}></Nav>
        {_article}
      </div>
    )
  }
}

class Title extends Component {
  render() {
    return (
      <header>
        <h1>{this.props.title}</h1>
      </header>
    )
  }
}

class Nav extends Component {
  render() {
    var _data = this.props.data;
    var list = [];
    for (let i = 0; i < _data.length; i++) {
      list.push(<li key={_data[i]}><a href={_data[i]} onClick={function (e) {
        e.preventDefault();
        this.props.clickNav(_data[i]);
      }.bind(this)}>{_data[i]}</a></li >)
    }
    return (
      <nav>
        <ul>
          {list}
        </ul>
      </nav >
    )
  }
}

class Article extends Component {
  render() {
    return (
      <article>
        <p>{this.props.content}</p>
      </article>
    )
  }
}

export default App;
