var express = require('express');
var Book = require('../models/book');
var router = express.Router();

/* GET home page. */
// router.get('/', function(req, res, next) {
//   res.render('index', { title: 'Express' });
// });

// GET ALL BOOKS
router.get('/books', function (req, res) {
  Book.find(function (err, books) {
    if (err) return res.status(500).send({ error: 'database failure' });
    res.json(books);
  })
})

// GET BOOK WITH PAGINATE
// sort({ket : 1}) 오름   -1 내림
router.get('/books/page/:page', function (req, res) {
  var page = Math.max(1, req.params.page);
  var limit = 5;
  Book.count(function (err, cnt) {
    if (err) return res.json({ success: false, message: err });
    var skip = (page - 1) * limit;
    var _maxPage = Math.ceil(cnt / limit);
    Book.find().sort({ _id: -1 }).skip(skip).limit(limit).exec(function (err, books) {
      res.json([books, _maxPage]);
    });
  });
});

// GET SINGLE BOOK
router.get('/books/:book_id', function (req, res) {
  Book.findOne({ _id: req.params.book_id }, function (err, book) {
    if (err) return res.status(500).json({ error: err })
    if (!book) return res.status(404).json({ error: 'book not found' });
    res.json(book);
  })
})
// $or : {author: keyword}, {title : keyword}
// GET BOOK SEARCH WITH PAGINATE
// sort({ket : 1}) 오름   -1 내림
router.get('/books/search/:select/:keyword/:page', function (req, res) {
  var page = Math.max(1, req.params.page);
  var limit = 5;
  var _author = req.params.select.split(',')[0]
  var _title = req.params.select.split(',')[1]
  var _keyword = { $regex: '.*' + req.params.keyword + '.*' }
  Book.count(function (err, cnt) {
    if (err) return res.json({ success: false, message: err });
    var skip = (page - 1) * limit;
    var _maxPage = Math.ceil(cnt / limit);
    Book.find().or([{ [_author]: _keyword }, { [_title]: _keyword }]).sort({ _id: -1 }).skip(skip).limit(limit).exec(function (err, books) {
      res.json([books, _maxPage]);
    });
  }).or([{ [_author]: _keyword }, { [_title]: _keyword }]);
});

// CREATE BOOK
router.post('/books', function (req, res) {

  var book = new Book();
  book.title = req.body.title;
  book.author = req.body.author;
  book.published_date = new Date(req.body.published_date);

  book.save(function (err) {
    if (err) {
      console.error(err);
      res.json({ result: 0 });
      return;
    }
    res.json({ result: 1 })
  })

})

// UPDATE THE BOOK
router.put('/books/:book_id', function (req, res) {
  Book.findById(req.params.book_id, function (err, book) {
    if (err) return res.status(500).json({ error: 'database failure' });
    if (!book) return res.status(404).json({ error: 'book not found' });

    if (req.body.title) book.title = req.body.title;
    if (req.body.author) book.author = req.body.author;
    if (req.body.published_date) book.published_date = req.body.published_date;

    book.save(function (err) {
      if (err) res.status(500).json({ error: 'failed to update' });
      res.json({ message: 'book updated' });
    })

  })
})

// UPDATE THE BOOK (ALTERNATIVE) -> 기존 document를 조회할 필요가 없다면
// app.put('/api/books/:book_id', function (req, res) {
//     Book.update({ _id: req.params.book_id }, { $set: req.body }, function (err, output) {
//         if (err) res.status(500).json({ error: 'database failure' });
//         console.log(output);
//         if (!output.n) return res.status(404).json({ error: 'book not found' });
//         res.json({ message: 'book updated' });
//     })
// });

// DELETE BOOK
router.delete('/books/:book_id', function (req, res) {
  Book.remove({ _id: req.params.book_id }, function (err, output) {
    if (err) return res.status(500).json({ error: "database failure" });
    res.status(204).end()
  })

})

module.exports = router;
