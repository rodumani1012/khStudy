import React, { Component } from 'react';
import './App.css';

import List from './components/List';
import Write from './components/Write';
import Detail from './components/Detail';
import Update from './components/Update';

class App extends Component {
  state = {
    mode: 'List',
    selected_id: ''
  }

  toListPage() {
    this.setState({ mode: 'List', selected_id: '' })
  }

  toMovePage(page) {
    this.setState({ mode: page })
  }

  render() {
    console.log('App render');

    var _page = null;

    if (this.state.mode === 'List') {
      _page = <List onChangePage={this.toMovePage.bind(this, 'Write')} onToDetail={function (_id) {
        this.setState({
          mode: 'Detail',
          selected_id: _id
        })
      }.bind(this)}></List>
    } else if (this.state.mode === 'Write') {
      _page = <Write toListPage={this.toListPage.bind(this)}></Write>
    } else if (this.state.mode === 'Detail') {
      _page = <Detail _id={this.state.selected_id} toListPage={this.toListPage.bind(this)} toUpdatePage={this.toMovePage.bind(this, 'Update')}></Detail>
    } else if (this.state.mode === 'Update') {
      _page = <Update _id={this.state.selected_id} toDetailPage={this.toMovePage.bind(this, 'Detail')}></Update>
    }

    return (
      <div className="App">
        {_page}
      </div>
    );
  }
}

export default App;
