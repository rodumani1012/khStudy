import React, { Component } from 'react';
import axios from 'axios';
import '../style.css';

class List extends Component {
    state = {
        lists: [],
        page: 1,
        maxPage: 1,
        select: "",
        keyword: ""
    }

    componentDidMount() {
        this.searchMongo()
    }

    searchMongo(_page, mode) {
        var _select, _keyword = null;
        if (mode === 'search') {
            _select = document.getElementById("select").value;
            _keyword = document.getElementById("keyword").value;
        } else if (mode === 'page') {
            _select = this.state.select;
            _keyword = this.state.keyword;
        }

        if (_keyword === null || _keyword === "") {
            this.getPagingList(_page);
        } else {
            this.searchAxios(_select, _keyword, _page)
        }
    }

    getPagingList(_page) {
        axios.get(`/api/books/page/${_page}`)
            .then(function (response) {
                this.setState({
                    lists: response.data[0],
                    page: _page,
                    maxPage: Number(response.data[1]),
                    select: "",
                    keyword: ""
                })
            }.bind(this))
            .catch(function (response) {
                console.log('error: ', response);
            })
    }

    searchAxios(_select, _keyword, _page) {
        axios.get(`/api/books/search/${_select}/${_keyword}/${_page}`)
            .then(function (response) {
                console.log(response.data);
                this.setState({
                    lists: response.data[0],
                    page: _page,
                    maxPage: Number(response.data[1]),
                    select: _select,
                    keyword: _keyword
                })
            }.bind(this))
            .catch(function (response) {
                console.log('error: ', response);
            })
    }

    render() {
        console.log('List render');
        var _page = [];
        for (let i = 1; i <= this.state.maxPage; i++) {
            _page.push(<a key={i + "_page"} href={"/page/" + i} onClick={function (e) { e.preventDefault(); this.searchMongo(i, 'page') }.bind(this)}> {i} </a>)
        }
        return (
            <div className="List">
                <div className="div_title"><h1>L I S T</h1></div>
                <div className="div_table">
                    <table>
                        <colgroup>
                            <col width="120px" />
                            <col width="450px" />
                            <col width="180px" />
                        </colgroup>
                        <thead>
                            <tr>
                                <th>Author</th>
                                <th>Title</th>
                                <th>Published Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.state.lists.map(item =>
                                <tr key={item._id}>
                                    <td >{item.author}</td>
                                    <td ><a href={"/detail/" + item._id} onClick={function (_id, e) {
                                        e.preventDefault();
                                        this.props.onToDetail(_id);
                                    }.bind(this, item._id)}>{item.title}</a></td>
                                    <td >{item.published_date.substr(0, 10)}</td>
                                </tr>
                            )}
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colSpan="3">
                                    {_page}
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                    <div className="div_write"><input type="button" value="Write" className="btn btn_write" onClick={function () { this.props.onChangePage() }.bind(this)}></input></div>
                </div>
                <div className="div_search">
                    <select id="select">
                        <option value="author">author</option>
                        <option value="title">title</option>
                        <option value="author,title">author+title</option>
                    </select>
                    <input type="text" id="keyword"></input>
                    {/* <input type="button" value="검색" onClick={this.searchMongo.bind(this, 1, 'search')}></input> */}
                    <input type="button" value="검 색" className="btn btn_search" onClick={this.searchMongo.bind(this, 1, 'search')}></input>
                </div>
            </div>
        );
    }
}

export default List;