import React, { Component } from 'react';
import axios from 'axios';
import '../style.css';

class Write extends Component {
    state = { lists: [] }

    insertMongo(e) {
        axios.post('/api/books', {
            'title': e.target.title.value,
            'author': e.target.author.value,
            'published_date': e.target.date.value
        })
            .then(function (response) {
                console.log('Createbook:', response);
            })
            .catch(function (error) {
                console.log('Createerror:', error);
            })
    }

    render() {
        console.log('Write render');
        return (
            <div className="Write">
                <div className="div_title"><h1>W R I T E</h1></div>
                <div className="div_table">
                    <form action="/api/books" method="post" onSubmit={function (e) {
                        e.preventDefault();
                        this.insertMongo(e);
                        this.props.toListPage();
                    }.bind(this)}>
                        <table>
                            <colgroup>
                                <col width="250px" />
                                <col width="500px" />
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th>Author</th>
                                    <td><input type="text" name="author"></input></td>
                                </tr>
                                <tr>
                                    <th>Title</th>
                                    <td><input type="text" name="title"></input></td>
                                </tr>
                                <tr>
                                    <th>Date</th>
                                    <td><input type="date" name="date"></input></td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colSpan="3">
                                        <input type="submit" value="Commit" className="btn"></input>
                                        <input type="button" value="Cancle" className="btn_cancle" onClick={function () {
                                            this.props.toListPage();
                                        }.bind(this)}></input>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </form>
                </div>
            </div>
        )
    }
}

export default Write;