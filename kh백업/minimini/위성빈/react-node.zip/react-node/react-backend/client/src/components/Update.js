import React, { Component } from 'react';
import axios from 'axios';

class Update extends Component {
    state = {
        title: '',
        author: '',
        date: ''
    }
    componentDidMount() {
        axios.get('/api/books/' + this.props._id)
            .then(function (response) {
                this.setState({
                    title: response.data.title,
                    author: response.data.author,
                    date: response.data.published_date
                })
            }.bind(this))
            .catch(function (response) {
                console.log('error: ', response);
            })
    }

    updateMongo(e) {
        axios.put('/api/books/' + this.props._id, {
            'title': e.target.title.value,
            'author': e.target.author.value,
            'published_date': e.target.date.value
        })
            .then(function (request) {
                console.log('Updatebook: ', request);
            })
            .catch(function (error) {
                console.log('Updateerror: ', error);
            })
    }

    inputHandler(e) {
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    render() {
        return (
            <div className="Update">
                <div className="div_title"><h1>U P D A T E</h1></div>
                <div className="div_table">
                    <form action="/books/" onSubmit={function (e) {
                        e.preventDefault();
                        this.updateMongo(e);
                        this.props.toDetailPage();
                    }.bind(this)}>
                        <table>
                            <colgroup>
                                <col width="250px" />
                                <col width="500px" />
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th>Author</th>
                                    <td><input type="text" name="author" value={this.state.author} onChange={this.inputHandler.bind(this)}></input></td>
                                </tr>
                                <tr>
                                    <th>Title</th>
                                    <td><input type="text" name="title" value={this.state.title} onChange={this.inputHandler.bind(this)}></input></td>
                                </tr>
                                <tr>
                                    <th>Date</th>
                                    <td><input type="date" name="date" value={(this.state.date + "").substring(0, 10)} onChange={this.inputHandler.bind(this)}></input></td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colSpan="3">
                                        <input type="submit" className="btn" value="Commit"></input>
                                        <input type="button" className="btn_cancle" value="Cancle" onClick={function () { this.props.toDetailPage() }.bind(this)}></input>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </form>
                </div>
            </div>
        );
    }
}

export default Update;