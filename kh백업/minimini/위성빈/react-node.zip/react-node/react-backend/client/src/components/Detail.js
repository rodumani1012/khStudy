import React, { Component } from 'react';
import axios from 'axios';
import '../style.css';

class Detail extends Component {
    state = { item: [] }

    deleteMongo() {
        axios.delete('/api/books/' + this.props._id)
            .then(function (response) {
                console.log('Delete: ', response);
                this.props.toListPage();
            }.bind(this))
            .catch(function (response) {
                console.log('DeleteError: ', response);
            })
    }

    componentDidMount() {
        axios.get('/api/books/' + this.props._id)
            .then(function (response) {
                this.setState({
                    item: response.data
                })
            }.bind(this))
            .catch(function (response) {
                console.log('error: ', response);
            })
    }

    render() {
        console.log('Detail render');
        return (
            <div className="Detail">
                <div className="div_title"><h1>D E T A I L</h1></div>
                <div className="div_table">
                    <table>
                        <colgroup>
                            <col width="250px" />
                            <col width="500px" />
                        </colgroup>
                        <tbody>
                            <tr>
                                <th>Author</th>
                                <td>{this.state.item.author}</td>
                            </tr>
                            <tr>
                                <th>Title</th>
                                <td>{this.state.item.title}</td>
                            </tr>
                            <tr>
                                <th>Date</th>
                                <td>{(this.state.item.published_date + "").substr(0, 10)}</td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colSpan="3">
                                    <input type="button" className="btn" value="Update" onClick={function () { this.props.toUpdatePage() }.bind(this)}></input>
                                    <input type="button" className="btn_delete" value="Delete" onClick={this.deleteMongo.bind(this)}></input>
                                    <input type="button" className="btn_cancle" value="Cancle" onClick={function () {
                                        this.props.toListPage();
                                    }.bind(this)}></input>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        );
    }
}

export default Detail;